
// yana configuration file. except for css, this is all you should
// have to mess with.

// supported "types" for each section: rss, html, opensearch, favorites.
// for rss you can optionally specify cache and prefetch settings (will default do something otherwise)
// for rss need some way to specify how many levels to go if > 1. For example: Archives -> Issues -> Articles in an Issue
// question: how to pass images for rss list items? not sure yet.

var YANA = {}; // but do not mess with this line

{

    // configure each of the main yana sections.

    var current = {
	label: "Current",
	id: "current",
	type: "rss",
	img: "img/icons/book_24.png",
	url: "http://pdrjournal.org/blog.xml",
	cache: 20,
	prefetch: 10
    };

    // question how do we support multi level menus? rss to issues to articles.
    var archive =  {
	label: "Archive",
	id: "archive",
	type: "rss",
	img: "img/icons/storage_24.png",
	url: "http://pdrjournal.org/yana/archive.xml",
	levels: 2
    };

    // TODO: opensearch is going to take some extra work...
    var search =  {
	label: "Search",
	id: "search",
	type: "opensearch",
	img: "img/icons/magnifier_24.png",
	url: "http://pdrjournal.org/yana/opensearch"
    };

    // TODO: favorites are going to take some extra work...
    var favorites =  {
	label: "Favorites",
	id: "favorites",
	type: "favorites",
	img: "img/icons/star_24.png",
	webapp: false
    };

    var about = {
	label: "About",
	id: "about",
	type: "html",
	img: "img/icons/info_24.png",
	url: "http://pdrjournal.org/yana/about.html"
    };

    var announcements = {
	label: "Announcements",
	id: "announcements",
	type: "rss",
	img: "img/icons/speaker_24.png",
	url: "http://pdrjournal.org/yana/announcements.rss"
    };

    var forAuthors = {
	label: "For Authors",
	id: "forAuthors",
	type: "html",
	img: "img/icons/pencil_24.png",
	url: "http://pdrjournal.org/yana/forAuthors.html"
    };

    var links = {
	label: "Links",
	id: "links",
	img: "img/icons/link_24.png",
	url: "http://pdrjournal.org/yana/links.rss"
    };
    
    // which sections do you want to list in the top content list?
    //YANA.contentSections = [ current, archive, search, favorites ];

   YANA.contentSections = [ current ];

    // which sections do you want to list in the bottom metadata list?

    YANA.metaSections = [ about, announcements, forAuthors, links ];
    
    alert("Hello: " + YANA.contentSections.length);
}